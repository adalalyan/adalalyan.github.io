function [ dist, angle ] = LoFT_desc_distance( f1, f2, sigma1, sigma2, N )

% this function computes the distance between two descriptors
% defined by the function "LoFT_descriptor"

k = size(f1,1)*size(f1,2)/8;

f1 = double(f1);
f2 = double(f2);

f1 = f1(1:2:end,:)+i*f1(2:2:end,:);
f2 = f2(1:2:end,:)+i*f2(2:2:end,:);

norm_factor = (sigma1.^2+sigma2.^2)'/min(mean(sigma1.^2+sigma2.^2),1);

d0 = sum(sum(abs(f1 - f2).^2)./norm_factor);
tau0 = 0;

tau = 2*pi*(1:N)/N;

for j = 1:N
    M_tau = repmat(exp(i*tau(j)*(1:k))',1,4);
    d = sum(sum(abs(f1 - M_tau.*f2).^2)./norm_factor);
    if d<d0
        d0 = d;
        tau0 = tau(j);
    end
end

tau = tau0-(2*pi/N) + 2*tau/N;


for j = 1:N
    M_tau = repmat(exp(i*tau(j)*(1:k))',1,4);
    d = sum(sum(abs(f1 - M_tau.*f2).^2)./norm_factor);
    if d<d0
        d0 = d;
        tau0 = tau(j);
    end
end

dist = d0/min(mean(sigma1.^2+sigma2.^2),1);


angle = tau0;