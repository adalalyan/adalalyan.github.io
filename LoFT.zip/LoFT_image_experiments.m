% by Arnak S. Dalalyan
% This the m-file which allows to get the results of Section 5, Fig. 5 in 
%    O. Collier and A. Dalalyan 
%    "Curve registration by nonparametric goodness-of-fit testing"
%    arXiv:1104.4210 [math.ST]


%% We use an image of the armenian church Akhtamar 

	I = imread('akhtamar_1.jpg');
	I=double(I);


%% We now draw a circle of radius r around the keypoint (x0,y0) 

	I1 = I;

	x0 = 140;
	y0 = 240;

	r = 64;

	for i=1:size(I,1)
  	  for j=1:size(I,2)
    	    if (sqrt((i-x0)^2+(j-y0)^2)>=r)&&(sqrt((i-x0)^2+(j-y0)^2)<r+1)
      	      I1(i,j,:) = [255 255 0];
        	end
    	end
	end

	image(uint8(I1),'CDataMapping','scaled');
	axis image; axis off;
	%colormap('bone')


	%% We define a new image I2 which contains only the neighborhood of I
	%  around (x0,y0) with radius r that will be used for building the
	%  local descriptor of the keypoint (x0,y0)

	I2 =I;
	for i=1:size(I,1)
    for j=1:size(I,2)
        if (sqrt((i-x0)^2+(j-y0)^2)>r)
            I2(i,j,:) = [255 255 255];
        end
    end
	end

	I2 = I2((x0-r):(x0+r),(y0-r):(y0+r),:);

	figure()
	subplot(1,2,1)
	image(uint8(I2),'CDataMapping','scaled');
	axis image; axis off;
	%colormap('bone')

	%% Just for visualization, we define a new image I3 which shows the 4
	%  rings around the keypoint used for defining the local descriptor 

	myfilter = fspecial('gaussian',[5 5], 0.7);
	I3 = imfilter(I3, myfilter, 'replicate');

	for n = 1:3
  	  rad = r*sqrt(n)/2;
	    for i=1:(round(rad))
        	I3(round(r+1-rad)+i, round(r+1+sqrt(rad^2-(rad-i)^2)),:) = [255 0 0];
        	I3(round(r+1-sqrt(rad^2-(rad-i)^2)), round(r+1-rad)+i,:) = [255 0 0];
        	I3(round(r+1+rad)-i, round(r+1+sqrt(rad^2-(rad-i)^2)),:) = [255 0 0];
        	I3(round(r+1-sqrt(rad^2-(rad-i)^2)), round(r+1+rad)-i,:) = [255 0 0];
        
        	I3(round(r+1-rad)+i, round(r+1-sqrt(rad^2-(rad-i)^2)),:) = [255 0 0];
        	I3(round(r+1+sqrt(rad^2-(rad-i)^2)), round(r+1-rad)+i,:) = [255 0 0];
        	I3(round(r+1+rad)-i, round(r+1-sqrt(rad^2-(rad-i)^2)),:) = [255 0 0];
        	I3(round(r+1+sqrt(rad^2-(rad-i)^2)), round(r+1+rad)-i,:) = [255 0 0];
    	end
	end


	subplot(1,2,2)
	image(uint8(I3),'CDataMapping','scaled');
	axis image; axis off;
	%colormap('bone')


	%% For visualization, we define a new image I4 which corresponds to a 
	%  sampled version of I3 after using the transformation 
	%  "cartesian ->  polar"
	
	Mat = [];
	
	for i=1:(2*r+1)
    	for j=1:(2*r+1)
   	%     Mat(ind,3:5) = I3(i,j,:);
        	x_current = i-r-1;
        	y_current = j-r-1;
        	[theta,rho] = cart2pol(x_current,y_current);
        	if (rho <= r)&&(rho>0)
            Mat = [Mat ; [theta rho I2(i,j,1) I2(i,j,2) I2(i,j,3)]];
	        end
    	end
	end

	Mat(:,2) = round(2*Mat(:,2));

	Mat(:,1) = (Mat(:,1)+pi);

	Mat(:,1) = round(1+(64*Mat(:,1)/pi));

	I4bis = zeros(2*r,2*r,3);
	I4 = 255 + I4bis;

	for i=1:size(Mat,1)
    	I4(Mat(i,2),Mat(i,1),:) = Mat(i,3:5);
    	I4bis(Mat(i,2),Mat(i,1),:) = Mat(i,3:5);
	end

	figure()
	image(uint8(I4));
	axis image; 
	axis on
	axis off;
	%colormap('bone')

%%  We plot now the four curves that correspond to the four rings
%   integrated over the values of the radius

I4bis = rgb2gray(I4bis);
curve1 = mean(I4bis(1:64,:));
curve2 = mean(I4bis(65:90,:));
curve3 = mean(I4bis(91:110,:));
curve4 = mean(I4bis(111:end,:));

z = 2*pi*(1:max(size(curve1)))/max(size(curve1));
figure()
subplot(4,1,1)
plot(z,curve4,'linewidth',2);
xlim([0,6.29])

subplot(4,1,2)
plot(z,curve3,'linewidth',2);
xlim([0,6.29])

subplot(4,1,3)
plot(z,curve2,'linewidth',2);
xlim([0,6.29])

subplot(4,1,4)
plot(z,curve1,'linewidth',2);
xlim([0,6.29])

%%  We plot now the smoothed versions of these four curves that are
%   obtained by removing the high-frequencies of the Fourier transform

f_c1 = fft(curve1);
f_c1(18:(end-16))=0;
curve1_smooth = ifft(f_c1);

figure()
subplot(4,1,4)
plot(z,curve1_smooth,'linewidth',2);
xlim([0,6.29])

f_c2 = fft(curve2);
f_c2(18:(end-16))=0;
curve2_smooth = ifft(f_c2);

subplot(4,1,3)
plot(z,curve2_smooth,'linewidth',2);
xlim([0,6.29])

f_c3 = fft(curve3);
f_c3(18:(end-16))=0;
curve3_smooth = ifft(f_c3);

subplot(4,1,2)
plot(z,curve3_smooth,'linewidth',2);
xlim([0,6.29])


f_c3 = fft(curve4);
f_c3(18:(end-16))=0;
curve4_smooth = ifft(f_c3);

subplot(4,1,1)
plot(z,curve4_smooth,'linewidth',2);
xlim([0,6.29])

%%  We do the same for an image I2_rot obtained from I2 by a 90� rotation
%
for j=1:size(I2,3) 
    I2_rot(:,:,j) = I2(:,:,j)';
end
I2_rot(:,1:end,:)=I2_rot(:,end:-1:1,:);

subplot(1,2,1)
image(uint8(I2),'CDataMapping','scaled');
axis image; axis off;
subplot(1,2,2)
image(uint8(I2_rot),'CDataMapping','scaled');
axis image; axis off;
%colormap('bone')

%% For visualization, we define a new image I4 which corresponds to a 
%  sampled version of I3 after using the transformation 
%  "cartesian ->  polar"

Mat = [];

for i=1:(2*r+1)
    for j=1:(2*r+1)
   %     Mat(ind,3:5) = I3(i,j,:);
        x_current = i-r-1;
        y_current = j-r-1;
        [theta,rho] = cart2pol(x_current,y_current);
        if (rho <= r)&&(rho>0)
            Mat = [Mat ; [theta rho I2_rot(i,j,1) I2_rot(i,j,2) I2_rot(i,j,3)]];
        end
    end
end

Mat(:,2) = round(2*Mat(:,2));

Mat(:,1) = (Mat(:,1)+pi);

Mat(:,1) = round(1+(64*Mat(:,1)/pi));

I4bis = zeros(2*r,2*r,3);

for i=1:size(Mat,1)
    I4bis(Mat(i,2),Mat(i,1),:) = Mat(i,3:5);
end


%%  We plot now the four curves that correspond to the four rings
%   integrated over the values of the radius

I4bis = rgb2gray(I4bis);
curve1 = mean(I4bis(1:64,:));
curve2 = mean(I4bis(65:90,:));
curve3 = mean(I4bis(91:110,:));
curve4 = mean(I4bis(111:end,:));

z = 2*pi*(1:max(size(curve1)))/max(size(curve1));

f_c1 = fft(curve1);
f_c1(18:(end-16))=0;
curve1_smooth = ifft(f_c1);

figure()
subplot(4,1,4)
plot(z,curve1_smooth,'linewidth',2);
xlim([0,6.29])

f_c2 = fft(curve2);
f_c2(18:(end-16))=0;
curve2_smooth = ifft(f_c2);

subplot(4,1,3)
plot(z,curve2_smooth,'linewidth',2);
xlim([0,6.29])

f_c3 = fft(curve3);
f_c3(18:(end-16))=0;
curve3_smooth = ifft(f_c3);

subplot(4,1,2)
plot(z,curve3_smooth,'linewidth',2);
xlim([0,6.29])


f_c3 = fft(curve4);
f_c3(18:(end-16))=0;
curve4_smooth = ifft(f_c3);

subplot(4,1,1)
plot(z,curve4_smooth,'linewidth',2);
xlim([0,6.29])

%% Here we perform the main experiment of Section 5, which aims at measuring the discriminative power
%  of the LoFT descriptor.


% different levels of noise are considered
sigma = [5 10 30 60];


for j=1:4
    figure()
    tic; 
    [ distances_H0_known_sigma, distances_H1_known_sigma, distances_H0_unknown_sigma, distances_H1_unknown_sigma ] = LoFT_axtamar_exp1( 10000 , sigma(j) );
    toc
    close()
    subplot(2,4,j)
    boxplot(log([distances_H0_known_sigma' distances_H1_known_sigma']))
    ylim([-.1 8.8])
    xlabel(['$\sigma=' num2str(sigma(j)) '$'],'Interpreter','latex','Units','points','FontSize',16);
    subplot(2,4,4+j)
    boxplot(log([distances_H0_unknown_sigma' distances_H1_unknown_sigma']))
    ylim([-.1 8.8])
    xlabel(['$\sigma=' num2str(sigma(j)) '$'],'Interpreter','latex','Units','points','FontSize',16);    
end

figure()
hist(distances_H0_known_sigma,30);
[h,x]=hist(distances_H0_known_sigma,30);
bar(x,h/trapz(x,h))
hold on
x=0.8:0.001:2.8;
plot(x, pdf('normal',x,mean(distances_H0_known_sigma),std(distances_H0_known_sigma)))
hold off