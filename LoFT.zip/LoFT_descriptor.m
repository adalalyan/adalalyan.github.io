function [ f , sigma ] = LoFT_descriptor( I, xy, r, k)
% compute a new local descriptor of the grayscale image I around the
% keypoint xy. 
%  - Input parameters
%     I    -- grayscale image
%     xy   -- 2-dim vector of integers indicating the location of the
%              key point
%     r    -- the radius of the ball around the keypoint used for defining
%             the local descriptor
%     k    -- the number of Fourier coefficients kept in the descriptor
%  - Output
%     f    -- local descriptor made of the Fourier coefficients
%    sigma -- an estimator of the noise magnitude.

%
%  As of June 7, 2013, the recommended values are r=32pxl, k=16
% 

if length(size(I))~=2
    disp('  ** Error: the first argument should be a 2D array');
end

nx = size(I,1);
ny = size(I,2);

x = xy(1);
y = xy(2);

if (x>nx)|(x<0)
    disp('  ** Error: the first value in the 2nd argument is out of range');
end


if (y>ny)|(y<0)
    disp('  ** Error: the 2nd value in the 2nd argument is out of range');
end

if (y+r>ny)|(y-r<0)|(x+r>nx)|(x-r<0)
    disp('  ** Error: the 3d argument is too large');
end

% restrict I to the neighborhood of interest
I = I((x-r):(x+r),(y-r):(y+r));

% initialization of the descriptor
f = zeros(k,4);
[X,Y] = meshgrid((-r):r,(-r):r);
[THETA,R] = cart2pol(X,Y);    
R(R==0)=1;
I(R==0)=0;
R_ring = sqrt((1:5)-1)*r/2;
sigma = zeros(4,1);

for i_ring = 1:4
    % define I1 by zeroing all pixels of I except those of the active ring
    I1 = 0*I;
    I1((R>R_ring(i_ring))&(R<=R_ring(i_ring+1))) = I((R>R_ring(i_ring))&(R<=R_ring(i_ring+1)));
    % To compute the integrals w.r.t. the polar coordinates, we should
    % normalize I1 by the number of pixels in each ring 4/r^2.
    I1 = 6*I1./(r^2);
    for i_freq = 1:k
        % compute the i_freq-th Fourier coefficient for the mean over the 
        % i_ring-th ring
        f(2*i_freq-1,i_ring) = sum(sum(I1.*sin(THETA*i_freq)));        
        f(2*i_freq,i_ring)   = sum(sum(I1.*cos(THETA*i_freq)));
    end
    
    for i_freq = (k+1):(2*k)
        % compute the i_freq-th Fourier coefficient for the mean over the 
        % i_ring-th ring
        sigma(i_ring) = sigma(i_ring) + (sum(sum(I1.*sin(THETA*i_freq))))^2;        
        sigma(i_ring) = sigma(i_ring) + (sum(sum(I1.*cos(THETA*i_freq))))^2;
    end
    sigma(i_ring) = (sigma(i_ring)/(k))^(1/2); 
end

%f = int8(f);
end

