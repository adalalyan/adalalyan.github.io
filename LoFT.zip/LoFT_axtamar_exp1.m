% by Arnak S. Dalalyan
% This the m-file which allows to get the results of Section 5, Fig. 5 in 
%    O. Collier and A. Dalalyan 
%    "Curve registration by nonparametric goodness-of-fit testing"
%    arXiv:1104.4210 [math.ST]


% this function is doing the following:
%   - adds a GWN of level sigma to the image axtamar_smooth 
%   - adds a GWN of level sigma to the rotated image axtamar_smooth
%   - randomly selects N points in the axtamar_smooth image
%   - computes the distance between each local descriptor and its
%     conterpart in the rotated image
%   - computes the distance between each local descriptor and a
%     descriptor in the rotated image sich that the two keypoints are not matching  


% The input arguments are 
%   - the number of points sampled in the first image
%   - the value of the noise standard deviation


function [ distances_H0_known_sigma, distances_H1_known_sigma, distances_H0_unknown_sigma, distances_H1_unknown_sigma ] = LoFT_axtamar_exp1( N , sigma )


% read the image and convert it to double
	I = double(imread('axtamar_gray.png'));

% define the rotated image 
	I_rot = I';
	I_rot = I_rot(:,end:-1:1);

% add independent Gaussian noise to both images
	I = I + sigma*randn(size(I));
	I_rot = I_rot + sigma*randn(size(I_rot));

% display the noisy images
	subplot(1,2,1)
	image(uint8(I),'CDataMapping','scaled');
	axis image; axis off;
	colormap('bone')

	subplot(1,2,2)
	image(uint8(I_rot),'CDataMapping','scaled');
	axis image; axis off;
	colormap('bone')

% estimate noise StD in each image using J. Immerkr, Fast Noise Variance Estimation, Computer Vision and
% Image Understanding, Vol. 64, No. 2, pp. 300-302, Sep. 1996
 
	S = estimate_noise(double(I));
	S_rot = estimate_noise(double(I_rot));

% Define the radius of the neighborhood to be considered around each point
	r = 32;

% this is just a trick to generate random points which are not too close to the
% boundary
	
	N1 = (size(I,1)-2*r);
	N2 = (size(I,2)-2*r);
	Perm = randperm(round(N1*N2/5));

% Initialize
	distances_H0_known_sigma = 0*(1:N);
	distances_H1_known_sigma = 0*(1:N);
	distances_H0_unknown_sigma = 0*(1:N);
	distances_H1_unknown_sigma = 0*(1:N);


% the main loop running over the set of points 
	for i=1:N
  	  Perm_i=5*Perm(i)-4;
  	  % this is to determine the image coordinates of the i-th point in the first image
    	col = fix(Perm_i/N1)+1;
    	row = Perm_i - N1*(col-1)+1;
    	x0  = r+row;
    	y0  = r+col;
% computes the LoFT descriptors of the keypoint in each image
    	[ f , sigma0 ] = LoFT_descriptor( I, [x0 y0], r, 16);
    	[ f1 , sigma1 ] = LoFT_descriptor( I_rot, [y0 size(I,1)+1-x0], r, 16);

% define the image coordinates of a point which is ad a distance 24pxl from the previous one
    	x1 = x0+10; 
    	y1 = y0+10;

    	if y1+r>=N2+2*r
        	y1 = y0-10;
    	end
    	
    	if size(I,1) +1 - x1-r<=0
        	x1 = x0-10;
    	end
% computes the LoFT descriptors of this new keypoint in the rotated image
    	[ f2 , sigma2 ] = LoFT_descriptor( I_rot, [y1 size(I,1)+1-x1], r, 16);

% computes the test statistic for the true matches
% (both for known and estimated sigma)
    	[ dist, angle ] = LoFT_desc_distance( f, f1, sigma*ones(4,1), sigma*ones(4,1), 200 ); 
    	[ dist1, angle1 ] = LoFT_desc_distance( f, f1, S*ones(4,1), S_rot*ones(4,1), 200 );     

    	distances_H0_known_sigma(i) = dist;
    	distances_H0_unknown_sigma(i) = dist1;    

% computes the test statistic for the false matches
% (both for known and estimated sigma)
    	[ dist, angle ] = LoFT_desc_distance( f, f2, sigma*ones(4,1), sigma*ones(4,1), 200 );     
    	[ dist1, angle1 ] = LoFT_desc_distance( f, f2, S*ones(4,1), S_rot*ones(4,1), 200 );
    	
    	distances_H1_known_sigma(i) = dist;
    	distances_H1_unknown_sigma(i) = dist1;    

	end

end