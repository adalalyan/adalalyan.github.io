 by Arnak S. Dalalyan
 The files included in this zip archive may be used to compute the LoFT descriptor, to match LoFT descriptors 
 as well as to reproduce all the results of Section 5 in 
    O. Collier and A. Dalalyan 
    "Curve registration by nonparametric goodness-of-fit testing"
    arXiv:1104.4210 [math.ST]


 - Execute LoFT_image_experiments.m if you want to reproduce all the results presented in the figures of Section 5.

 - Use the function "LoFT_descriptor" to compute the descriptor of a point in a grayscale image.
 
 - Use "LoFT_desc_distance" to compute the normalized distance between two descriptors which is used as a test 
   statistic. The following thresholds are recommending for deciding whether two points are match or not:
    *  tol =   5%    =>   threshold = 2.0401    
    *  tol =   1%    =>   threshold = 2.2205    
    *  tol = 0.1%    =>   threshold = 2.4341
 