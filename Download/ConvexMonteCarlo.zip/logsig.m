function f = logsig(x)
    if x<0
        f = exp(x)./(1+exp(x));
    else
        f = 1./(1+exp(-x));
    end
end