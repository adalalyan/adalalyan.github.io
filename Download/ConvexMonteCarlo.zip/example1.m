function [ elapsedTime, direct, LMC, LMCO ] = example1( p_values, epsilon, N , NO_LMC)
%EXAMPLE1 Summary of this function goes here
%   Detailed explanation goes here

nb_p = max(size(p_values));

for j=1:nb_p
    p = p_values(j);
    a = ones(p,1)/sqrt(2*p);
    aa = repmat(a,1,N);
    
    direct{j} = zeros(p,N);
    LMC{j} = zeros(p,N);
    LMCO{j} = zeros(p,N);

    tic
    Y = repmat((rand(1,N)>0.5),p,1);
    Z = randn(p,N);
    % this samples directly from the target distribution pi
    direct{j} = Y.*(Z-aa) + (1-Y).*(Z+aa);
    % this computes the average running time for drawing one sample
    % using the direct method
    elapsedTime(j,1)  = toc/N;
        
    
    % We compute now N samples drawn from pi using the LMC method
    M = 1;
    LMCj = randn(p,N)/sqrt(2*M);
    T = 4*log(1/epsilon)+p*log(2);
    alpha = (1+p*T/epsilon^2)/2;
    h = epsilon^2*(2*alpha-1)/(T*p*alpha);
    K = round(T/h);
    %disp(['  ** for p = ', num2str(p), ' nb of iter for LMC ' num2str(K)]);
    disp(['  ** -----------------------------']);
    disp(['  ** current p = ', num2str(p)]);
    disp(['  **      nb iter LMC  ' num2str(K)]);
    tic
    if NO_LMC==0
        for k = 1:K
            LMCj = LMCj - h*gradf(LMCj,a)+sqrt(2*h)*randn(p,N);
        end
    end
    % this computes the average running time for drawing one sample
    % using the LMC method
    elapsedTime(j,2)  = toc/N;
    LMC{j} = LMCj;
    disp(['  **      timing LMC   ' num2str(toc)]);
    
    % We compute now N samples drawn from pi using the LMCO method
    L_f = 1/(2*sqrt(8));
    h = min([(3*L_f*T*p/epsilon)^(-2/3),(L_f*sqrt(12*T)*p/epsilon)^(-1),(1/8)]);
    K = round(T/h);
    disp(['  **      nb iter LMCO ' num2str(K)]);    

    [U,D] = svd(a*a');
    D = eye(p)*(1-exp(-h));
    ULMCO = randn(p,N)/sqrt(2*M);
    [U,D] = svd(a*a');
   
    tic
    for k = 1:K
        H1 = exp(2*norm(a)*ULMCO(1,:));                 % 1xN vector
        H = 1-2*H1./(1+H1).^2;                          % 1xN vector
        M1 = (1-exp(-h*H))./H;                          % 1xN vector
        Sigma1 = (1-exp(-2*h*H))./H;
        ULMCO(1,:) = ULMCO(1,:) - M1.*(ULMCO(1,:)-norm(a)*(1-2./(1+H1)))+ sqrt(Sigma1).*randn(1,N);
        ULMCO(2:p,:) = ULMCO(2:p,:) - (1-exp(-h))*ULMCO(2:p,:)+sqrt(1-exp(-2*h))*randn(p-1,N);
    end
    LMCO{j} = U*ULMCO;
    % this computes the average running time for drawing one sample
    % using the LMC method
    elapsedTime(j,3)  = toc/N;
    disp(['  **      timing LMCO  ' num2str(toc)]);    
    disp(['  ** -----------------------------']);
end

function Y = gradf(X,a)
    p = max(size(a));
    if size(X,1)~=p
        disp('Error: dimension of X and a mismatch')
    else
        N = size(X,2);
        b = 1-(2./(1+exp(2*a'*X)));
        Y = X - a*b;
    end
    
  