
% This function applies LMC and LMCO algorithms to the logistic regression.
% The parameters h and T are determined by the theoretical results of our
% paper, except that the Poincar� inequality is replaced by the log-Sobolev
% inequality as it is suggusted by Durmus and Moulines.

function [ elapsedTime, LMC, LMCO, th_star ] = example2a(p, n_values, epsilon, N , method)
% input arguments
%  
%  method    - either 1 or 2 or anything else. If method==1, then only LMC is run. If
%              method==2, then only LMCO is run. Otherwise, both are run.
th_true = ones(p,1);

disp(['  ** -----------------------------']);

disp(['  **  true theta ' num2str(th_true')]);

nb_n = max(size(n_values));
LMC = cell(1,nb_n);
LMCO = cell(1,nb_n);
th_star = cell(1,nb_n);




for j=1:nb_n
    
    LMC{j} = zeros(p,N);
    LMCO{j} = zeros(p,N);    
    n = n_values(j);
    lambda = sqrt(n)/4;
    X = sign(randn(n,p))/sqrt(p);
    prob = logsig(-X*th_true);
    Y = (rand(n,1)<prob)*1;
    covX = (X'*X/n);
    [U,V] = svd(covX);
    A = U*diag(diag(V).^(-1/2))*U';
    Xold =X;
    X = X*A;
    m = lambda;
    M = lambda+0.25*n;
    L_g = 0.1*max(svd(X'*diag(sum(X'.^2).^(1/2))*X));
    

    % We first compute the mode th_star of the posterior
    
    eps1=1e-6;
    fmin = -norm(X'*Y)^2/(2*lambda);
    th_starj = zeros(p,1)+2;
    k_eps = log(2*(0-fmin)/(m*eps1^2))/log(2*M/(2*M-m));
    
    
    for k = 1:round(k_eps)
        th_starj = th_starj - (2*M)^(-1)*gradf(th_starj,X, Y, lambda*eye(p));
    end
    th_star{j} = A*th_starj;
    
    disp(['  **  theta PML  ' num2str(th_star{j}')]); 
    disp(['  ** -----------------------------']);
    
    % We compute now N samples drawn from pi using the LMC method
    LMCj = repmat(th_starj,1,N)+randn(p,N)/sqrt(M);    
    T = (log(1/epsilon)+log(p/sqrt(2))+log(1+log(M/(2*m))))/m;
    alpha = (1+M*p*T/epsilon^2)/2;
    h = epsilon^2*(2*alpha-1)/(M*T*p*alpha);
    K = round(T/h);

    T = (log(4/epsilon)+log(p/sqrt(2))+log(1+log(M/(2*m))))/m;    
    h1 = min((16*L_g*M*T*p/(7*epsilon))^(-2/3),(5*L_g*sqrt(T)*p/(7*epsilon))^(-1));
    h1 = min(h1,1/(8*M));
    
    
    h_range = h1+((0:10^6)/10^6)*((8*M)^(-1)-h1);
    KL = 0.267*(L_g*T*M*p)^2*h_range.^3+0.375*T*(L_g*p)^2*h_range.^2;
    ind = max(find(KL<=49*epsilon^2/64));
    h1 = h_range(ind);
    
    K1 = round(T/h1);  
    
    %disp(['  ** for p = ', num2str(p), ' nb of iter for LMC ' num2str(K)]);
    disp(['  ** current n = ', num2str(n)]);
    disp(['  **      nb iter LMC  ' num2str(K)]);
    disp(['  **      nb iter LMCO  ' num2str(K1)]);    
    tic
    if method~=2
        for k = 1:K
            LMCj = LMCj - h*gradf(LMCj, X, Y, lambda*eye(p))+sqrt(2*h)*randn(p,N);
            if rem(k,20*10^4)==0
                disp(['         ++   k=' num2str(k)]);
            end
        end
    end
    % this computes the average running time for drawing one sample
    % using the LMC method
    elapsedTime(j,1)  = toc/N;
    LMC{j} = A*LMCj;
    disp(['  **      timing LMC   ' num2str(toc)]);

    % We compute now N samples drawn from pi using the LMCO method
    h=h1;
    K = round(T/h);
        

    LMCOj = repmat(th_starj,1,N)+randn(p,N)/sqrt(M);    
  
    tic
    XX = repmat(X',N,1);                         % (pN x n) matrix
    
    if method~=1    
        for k = 1:K 
            D = logsig(X*LMCOj);
            D = D.*(1-D);      % n x N  matrix 
            Hk = zeros(N*p,p);
            if N<5*p
                    for l= 1:N
                        Hk((l-1)*p+(1:p),:) = lambda*eye(p) + X'*diag(D(:,l))*X;
                    end;
            else        
            DD = kron(D,ones(1,p))';            % (pN x n) matrix                              
            Hk = lambda* kron(ones(N,1),eye(p)) + XX.*DD*X;
            end
            Mk = h*(kron(ones(N,1),eye(p))-0.5*h*Hk);
            Sk = sqrt(2/h)*Mk;

%             for i=1:N
%                 range = ((i-1)*p+1):(i*p);
%                 [U_H,D_H] = eig(Hk(range,:));
%                 Mk(range,:) = U_H*(eye(p)-exp(-h*D_H))*inv(D_H)*U_H';
%                 Sk(range,:) = U_H*sqrt((eye(p)-exp(-2*h*D_H))*inv(D_H))*U_H';
%             end

            v =gradf(LMCOj, X, Y, lambda*eye(p));
            %v= newproduct(Mk,v);
            v = Mk.*repmat(reshape(v,p*N,1),1,p);
            v = sum(reshape(v,p,p*N));
            v = reshape(v',N,p)';        
            w = randn(p,N);
            w = Sk.*repmat(reshape(w,p*N,1),1,p);
            w = sum(reshape(w,p,p*N));
            w = reshape(w',N,p)';        
            %w = newproduct(Sk,w1);
            LMCOj1 = LMCOj - v + w;        
            if rem(k,10*10^3)==0
                disp(['         ++   k=' num2str(k)]);
            end
        end
        LMCO{j} = A*LMCOj;
        % this computes the average running time for drawing one sample
        % using the LMC method
    end        
    elapsedTime(j,2)  = toc/N;
    disp(['  **      timing LMCO  ' num2str(toc)]);    
    disp(['  ** -----------------------------']);
end
end    
    
function G = gradf(theta, X, Y, pen_mat)
    n = max(size(Y));
    p = size(X,2);
    if size(X,1)~=n
        disp('Error: dimension of X and Y mismatch')
    else
        if size(theta,1)~=p
            disp('Error: dimension of X and theta mismatch')
        else
            N = size(theta,2);
            G = repmat(X'*Y,1,N)+pen_mat*theta;
            G = G-X'*logsig(-X*theta);
        end
    end
end
    
function f = logsig(x)
    f = exp(x)./(1+exp(x));
end

function V = newproduct(A,X)
    % this function computes a new product of the matrices A and  X
    % A is a (pN)xp matrix of the form [A1;A2;...;AN] where each Ak is pxp
    % X is a pxN matrix with columns X1 X2 ... XN
    % the result V is a pxN matrix such that Vk = Ak*Xk
    p = size(A,2);
    N = size(X,2);
    V = A.*repmat(reshape(X,p*N,1),1,p);
    V = sum(reshape(V,p,p*N));
    V = reshape(V',N,p)';
end