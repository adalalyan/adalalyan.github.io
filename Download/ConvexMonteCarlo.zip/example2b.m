
% This function applies LMC and LMCO algorithms to the logistic regression.
% The parameters h and T are determined by the theoretical results of our
% paper, except that the Poincar� inequality is replaced by the log-Sobolev
% inequality as it is suggusted by Durmus and Moulines.

% We try here to apply the strong-convexification trick described in
% Section 4.3

function [ K_o, K_n ] = example2b(p, n_values, epss, beta, N)
% input arguments
%  
%  method    - either 1 or 2 or anything else. If method==1, then only LMC is run. If
%              method==2, then only LMCO is run. Otherwise, both are run.
    th_true = ones(p,1);


    disp(['  ** -----------------------------']);

    disp(['  **  true theta ' num2str(th_true')]);

    nb_n = max(size(n_values));
    
    K_o = zeros(1,nb_n);
    K_n = zeros(1,nb_n);
    th_star = cell(1,nb_n);

    for i=1:N
        disp(['  ']);
        disp(['  **     *****************************    *** ']);    
        disp(['  **      simu number   ' num2str(i) '    *** ']);
        disp(['  **     *****************************    *** ']);    
        disp(['  ']);  

        for j=1:nb_n
            n = n_values(j);
            lambda = 3*p/pi^2;
            X = sign(randn(n,p))/sqrt(p);
            prob = logsig(-X*th_true);
            Y = (rand(n,1)<prob)*1;
            covX = (X'*X/n);
            [U,V] = svd(covX);
            A = U*diag(diag(V).^(-1/2))*U';
            Xold =X;
            X = X*A;
            m = lambda;
            M = lambda+0.25*n;


            % We first compute the mode th_star of the posterior

            eps1=1e-6;
            fmin = -norm(X'*Y)^2/(2*lambda);
            th_starj = zeros(p,1);
            k_eps = log(2*(0-fmin)/(m*eps1^2))/log(2*M/(2*M-m));


            for k = 1:min(k_eps,10^3)
                th_starj = th_starj - (2*M)^(-1)*gradf(th_starj,X, Y, lambda*eye(p));
            end
            th_star{j} = A*th_starj;

            disp(['  **  theta PML  ' num2str(th_star{j}')]); 
            disp(['  ** -----------------------------']);

            % We now determine the best values R and gamma

            [ R, gamma ] = Ropt(n,p,epss/8,M,th_starj,X,lambda, beta);
            disp(['  **  R = ' num2str(R) ' ; gamma = ' num2str(gamma)]);

            % We compute now the number of iteration we would need without using the
            % strong convexification trick 
            T = (log(1/epss)+log(p/sqrt(2))+log(1+log(M/(2*m))))/m;
            alpha = (1+M*p*T/(epss)^2)/2;
            h = (epss)^2*(2*alpha-1)/(M*T*p*alpha);
            K_old = round(T/h);


            % We compute now N samples drawn from pi using the LMC method
            M = M+gamma;
            m = m+(1-beta^(-1))*gamma;
            T = (log((16/15)/epss)+log(p/sqrt(2))+log(1+log(M/(2*m))))/m;
            alpha = (1+M*p*T/(epss/2)^2)/2;
            h = (16*epss/15)^2*(2*alpha-1)/(M*T*p*alpha);
            K = round(T/h);

            disp(['  **  K old = ' num2str(K_old) '; K new = ' num2str(K)]);
            K_o(j) = K_o(j)+K_old/N;
            K_n(j) = K_n(j)+K/N;
        end  
    end
end    
    
function G = gradf(theta, X, Y, pen_mat)
    n = max(size(Y));
    p = size(X,2);
    if size(X,1)~=n
        disp('Error: dimension of X and Y mismatch')
    else
        if size(theta,1)~=p
            disp('Error: dimension of X and theta mismatch')
        else
            N = size(theta,2);
            G = repmat(X'*Y,1,N)+pen_mat*theta;
            G = G-X'*logsig(-X*theta);
        end
    end
end
    


function V = newproduct(A,X)
    % this function computes a new product of the matrices A and  X
    % A is a (pN)xp matrix of the form [A1;A2;...;AN] where each Ak is pxp
    % X is a pxN matrix with columns X1 X2 ... XN
    % the result V is a pxN matrix such that Vk = Ak*Xk
    p = size(A,2);
    N = size(X,2);
    V = A.*repmat(reshape(X,p*N,1),1,p);
    V = sum(reshape(V,p,p*N));
    V = reshape(V',N,p)';
end



% This function computes the local strong convexity constant for the
% logistic regression

function [ mR ] = smallm(R,n,th_star,X,lambda)
% X should be  n x p matrix
% th_star should be p-vector
    p = length(th_star);
    expon = abs(th_star'*X')+R*sqrt(sum(X'.^2));
    Diag = logsig(expon).*(1-logsig(expon));
    Nabla2 = (X'.*repmat(Diag,p,1))*X;
    [U,D] = eig(Nabla2);    
    mR = lambda+ min(diag(D));    
end

% This function computes an upper bound on the integral on B(R)^c of
% (|x-x*|-R)^2*pi(R)

function [ muR ] = pmuR(R,p,M,m,lambda)
    mR2 = m*R^2;
    numer = gammainc(mR2,p+4,'upper')*gamma(p+4)-...
            4*mR2*gammainc(mR2,p+3,'upper')*gamma(p+3)+...
            6*mR2^2*gammainc(mR2,p+2,'upper')*gamma(p+2)-...
            4*mR2^3*gammainc(mR2,p+1,'upper')*gamma(p+1)+...
            mR2^4*gammainc(mR2,p,'upper')*gamma(p);
    muR = 2*(M/2)^(p/2)*numer/((mR2)^(p+4)*gamma(p/2));
    muR = sqrt(muR);
end


% This function aims at maximizing wrt R the expression min(m_{2R}, m_\infty+eps^2/(p*mu_R))

function [ Rstar, gamma ] = Ropt(n,p,eps2,M,th_star,X,lambda,beta)

    R = 1;
    Rup = R;
    Rlow = 0;
    %beta = 1.001;
    mbetaR = smallm(beta*R,n,th_star,X,lambda);
    mR = smallm(R,n,th_star,X,lambda);

    while mbetaR > (lambda+2*(1-beta^(-1))*eps2/pmuR(R,p,M,mR,lambda))
        pmr = pmuR(R,p,M,mR,lambda);
        Rup = 2*R;
        Rlow = R;
        R=2*R;
        mbetaR = smallm(beta*R,n,th_star,X,lambda);
        mR = smallm(R,n,th_star,X,lambda);
    end
    
    while (Rup-Rlow)>1e-10
        R = (Rup+Rlow)/2;
        mbetaR = smallm(beta*R,n,th_star,X,lambda);
        mR = smallm(R,n,th_star,X,lambda);
        if mbetaR > (lambda+2*(1-beta^(-1))*eps2/pmuR(R,p,M,mR,lambda))
            Rlow = R;
        else
            Rup = R;
        end
    end
    Rstar = (Rup+Rlow)/2;
    mR = smallm(R,n,th_star,X,lambda);
    gamma = 2*eps2/pmuR(R,p,M,mR,lambda);
   % disp(['  ' num2str(mbetaR) '  **  ' num2str(lambda+2*(1-beta^(-1))*eps2/pmuR(R,p,M,mR,lambda))] )
end