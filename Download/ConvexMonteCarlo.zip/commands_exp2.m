% The commands below were used for carrying out the second sub-experiment
% of the manucript, in the framework of logistic regression

nn =[200 300 400 500];
p = 10;        
true_th = ones(1,p);        
N_simu = 100;
N_MC = 100;

err10 = zeros(5,length(nn));



parfor i = 1:N_simu
     [ elapsedTime, LMCj, LMCOj, th_starj ] = example2a(p ,nn, 0.1, N_MC, 0);
     LMC{i} = LMCj;
     LMCO{i} = LMCOj;
     th_star{i} = th_starj;
    disp(['** -- ** i = ' num2str(i) ' finished'])     
end     

for  i = 1:N_simu
     LMCj = LMC{i};
     LMCOj = LMCO{i};
     th_starj = th_star{i};
    for j=1:length(nn)
        n=nn(j);
        err10(1,j) = norm(th_starj{j}'-true_th);
        err10(2,j) = norm(median(LMCj{j}')-true_th);
        err10(3,j) = norm(mean(LMCj{j}')-true_th);    
        err10(4,j) = norm(median(LMCOj{j}')-true_th);
        err10(5,j) = norm(mean(LMCOj{j}')-true_th);    
    end
    disp(['** -- ** i = ' num2str(i) ' finished'])
    disp(num2str(err10));
    
end
    
estimates = cell(N_simu,length(nn));
for j=1:N_simu
    for ni = 1:length(nn)
        estimates{j,ni} = [norm(true_th-th_star{j}{ni}');
                           norm(true_th-mean(LMC{j}{ni}'));
                           norm(true_th-median(LMC{j}{ni}'));
                           norm(true_th-mean(LMCO{j}{ni}'));
                           norm(true_th-median(LMCO{j}{ni}'))];
                       vecPv = zeros(p,1);
                       for np=1:p
                           [H,Pv] = kstest2(LMCO{j}{ni}(np,:),LMC{j}{ni}(np,:));
                           vecPv(np)=Pv;
                       end
        ks(j,ni) = median(vecPv);
    end
end

averages = zeros(5,length(nn));

for ni = 1:length(nn)
    averages(:,ni) = zeros(5,1);
    for j=1:N_simu
        averages(:,ni) = averages(:,ni) + estimates{j,ni};
    end
    averages(:,ni) = averages(:,ni)/N_simu; 
end
averages

stds = zeros(5,length(nn));

for ni = 1:length(nn)
    for l = 1:5
        errors = zeros(N_simu,1);
        for j=1:N_simu
            errors(j) = estimates{j,ni}(l);
        end
        stds(l,ni) = std(errors);
    end
end
stds  


distMedian = zeros(N_simu,length(nn));
distMean = zeros(N_simu,length(nn));
distQ1 = zeros(N_simu,length(nn));
distQ3 = zeros(N_simu,length(nn));

% p=10;
% LMC = LMC10;
% LMCO = LMCO10;
for n1 = 1:N_simu
    for n2=1:length(nn)
        medianLMC{n1,n2} = median((LMC{n1}{n2})');
        medianLMCO{n1,n2} = median((LMCO{n1}{n2})');
        distMedian(n1,n2) = mean(abs(median((LMC{n1}{n2})')-median((LMCO{n1}{n2})')));
        distMean(n1,n2) = mean(abs(mean((LMC{n1}{n2})')-mean((LMCO{n1}{n2})')));        
        distQ1(n1,n2) = mean(abs(quantile((LMC{n1}{n2})',0.25)-quantile((LMCO{n1}{n2})',0.25)));
        distQ3(n1,n2) = mean(abs(quantile((LMC{n1}{n2})',0.75)-quantile((LMCO{n1}{n2})',0.75)));        
    end
end


for n2 = 1:length(nn)
    figure
    bplot([distMean(:,n2) distMedian(:,n2) distQ1(:,n2)  distQ3(:,n2)],'horiz');
    xlabel(['$n = $' num2str(nn(n2)) ' ;  $p = $' num2str(p)],'interpreter','latex');
    ax = gca;
    set(ax,'YTick',[1 2 3 4]);
    set(ax, 'YTickLabel', {'Mean','Med','Q1','Q3'});
end
   